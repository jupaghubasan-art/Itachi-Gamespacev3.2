package com.sanju.systemx.resolution

import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Shared resolution logic for Game Space. Only whitelisted `wm size` commands are ever sent to Shizuku. */
object ResolutionManager {
    data class Size(val w: Int, val h: Int)

    suspend fun physical(): Size? {
        val r = ShizukuBridge.exec("wm", "size")
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(r.out) ?: return null
        return Size(m.groupValues[1].toInt(), m.groupValues[2].toInt())
    }

    fun target(base: Size, scale: Float): Size {
        val s = scale.coerceIn(0.5f, 1.0f)
        return Size((base.w * s).toInt() and -2, (base.h * s).toInt() and -2)
    }

    suspend fun apply(p: Prefs, t: Size): ShizukuBridge.Result {
        val r = ShizukuBridge.exec("wm", "size", "${t.w}x${t.h}")
        if (r.code == 0) p.setB("res_modified", true)
        GsLog.d("Resolution", "apply ${t.w}x${t.h} code=${r.code}")
        return r
    }

    suspend fun reset(p: Prefs): ShizukuBridge.Result {
        val r = ShizukuBridge.exec("wm", "size", "reset")
        if (r.code == 0) p.setB("res_modified", false)
        GsLog.d("Resolution", "reset code=${r.code}")
        return r
    }
}

/** Safety net after a resolution change: reverts after 15 s unless the user taps KEEP. */
fun AppCompatActivity.keepOrRevert(prefs: Prefs, out: TextView) {
    val d = AlertDialog.Builder(this).setTitle("Keep this resolution?")
        .setMessage("Reverting in 15 s…").setCancelable(false)
        .setPositiveButton("KEEP") { _, _ -> out.text = "✓ Resolution kept." }
        .setNegativeButton("REVERT NOW") { _, _ ->
            lifecycleScope.launch {
                ResolutionManager.reset(prefs)
                out.text = "✓ Reverted to native resolution."
            }
        }.create()
    d.show()
    lifecycleScope.launch {
        for (i in 14 downTo 0) {
            delay(1000)
            if (!d.isShowing) return@launch
            d.setMessage("Reverting in $i s…")
        }
        if (d.isShowing) {
            d.dismiss()
            ResolutionManager.reset(prefs)
            out.text = "✓ No answer, so the resolution was reverted to native."
        }
    }
}
