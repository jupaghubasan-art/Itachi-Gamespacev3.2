package com.sanju.systemx.ui.animations

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Boot intro, driven by a single animator value t in 0..1 (about 1.7 s):
 * black → red vortex glow → energy line → burst with light streaks → logo → GAME SPACE.
 * Redraws only while the animator runs.
 */
class IntroView(ctx: Context) : View(ctx) {
    var t = 0f
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random(7)
    private val ang = FloatArray(30) { rnd.nextFloat() * 6.2832f }
    private val len = FloatArray(30) { 0.3f + rnd.nextFloat() * 0.7f }
    private var vortex: RadialGradient? = null
    private val d get() = resources.displayMetrics.density

    private fun seg(v: Float, a: Float, b: Float) = ((v - a) / (b - a)).coerceIn(0f, 1f)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        vortex = RadialGradient(w / 2f, h / 2f, max(w, h) * 0.6f,
            intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF4A0010.toInt(), 0xFF0E0003.toInt()),
            floatArrayOf(0f, 0.22f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2
        c.drawColor(0xFF000000.toInt())

        p.style = Paint.Style.FILL
        p.shader = vortex; p.alpha = (255 * seg(t, 0.1f, 0.4f)).toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        val la = seg(t, 0.22f, 0.5f)
        if (la > 0f) {
            val half = w * 0.22f * la
            p.style = Paint.Style.STROKE
            p.color = 0xFFFF6A3D.toInt(); p.alpha = (255 * la).toInt(); p.strokeWidth = 3 * d
            c.drawLine(cx - half, cy, cx + half, cy, p)
            p.alpha = (70 * la).toInt(); p.strokeWidth = 10 * d
            c.drawLine(cx - half, cy, cx + half, cy, p)
        }

        val burst = seg(t, 0.45f, 0.6f) * (1f - seg(t, 0.62f, 0.85f))
        if (burst > 0f) {
            p.style = Paint.Style.FILL
            p.color = 0xFFE9003C.toInt(); p.alpha = (210 * burst).toInt()
            c.drawRect(0f, 0f, w, h, p)
            p.style = Paint.Style.STROKE
            p.color = 0xFFFFFFFF.toInt(); p.alpha = (255 * burst).toInt(); p.strokeWidth = 2 * d
            val reach = max(w, h)
            for (i in ang.indices) {
                val l = reach * len[i] * burst
                c.drawLine(cx, cy, cx + cos(ang[i]) * l, cy + sin(ang[i]) * l, p)
            }
        }

        val ta = seg(t, 0.58f, 0.78f)
        val ga = seg(t, 0.72f, 0.92f)
        if (ta > 0f) {
            val r = h * 0.11f
            val hex = Path()
            for (k in 0 until 6) {
                val a = Math.toRadians(-90.0 + 60.0 * k).toFloat()
                val x = cx + cos(a) * r; val y = cy - h * 0.2f + sin(a) * r
                if (k == 0) hex.moveTo(x, y) else hex.lineTo(x, y)
            }
            hex.close()
            p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d
            p.color = 0xFFE9003C.toInt(); p.alpha = (255 * ta).toInt()
            c.drawPath(hex, p)
            val f = r / 32f
            val bx = floatArrayOf(4f, -12f, -2f, -6f, 12f, 1f)
            val by = floatArrayOf(-20f, 4f, 4f, 22f, -4f, -4f)
            val bolt = Path()
            for (k in 0 until 6) {
                val x = cx + bx[k] * f; val y = cy - h * 0.2f + by[k] * f
                if (k == 0) bolt.moveTo(x, y) else bolt.lineTo(x, y)
            }
            bolt.close()
            p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.alpha = (255 * ta).toInt()
            c.drawPath(bolt, p)

            p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            p.letterSpacing = 0.08f
            p.textSize = h * 0.11f * (0.9f + 0.1f * ta)
            p.color = 0xFFFFFFFF.toInt(); p.alpha = (255 * ta).toInt()
            c.drawText("SANJU SYSTEM X", cx, cy + h * 0.06f, p)
        }
        if (ga > 0f) {
            p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER
            p.letterSpacing = 0.3f; p.textSize = h * 0.075f
            p.color = 0xFFE9003C.toInt(); p.alpha = (255 * ga).toInt()
            c.drawText("GAME SPACE", cx, cy + h * 0.2f, p)
        }
    }
}
