package com.sanju.systemx.gamespace

import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.lifecycle.lifecycleScope
import com.sanju.systemx.R
import com.sanju.systemx.optimizer.OptimizationProfile
import com.sanju.systemx.resolution.ResolutionManager
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.components.AMBER
import com.sanju.systemx.ui.components.MATCH
import com.sanju.systemx.ui.components.WRAP
import com.sanju.systemx.ui.components.lp
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun pressAnim(v: View) {
    if (!Pal.anim) return
    v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80)
        .withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
}

fun GameSpaceActivity.launchGame(g: GameInfo) {
    lifecycleScope.launch {
        GameSessionManager.begin(prefs, monitor.sample(), g)
        val err = GameLauncher.launch(this@launchGame, g.pkg)
        if (err != null) { GameSessionManager.clear(prefs); toast(err) }
    }
}

/** BOOST (launchAfter=false) or BOOST & PLAY (true): confirm if disruptive, optimize, report, launch. */
fun GameSpaceActivity.startBoost(launchAfter: Boolean) {
    val game = vm.selectedGame()
    if (game == null) {
        toast("Please select a game first.")
        select(GameSpaceActivity.Section.GAMES)
        return
    }
    sfx.play(R.raw.sfx_boost, 0.7f)
    lifecycleScope.launch {
        val profile = OptimizationProfile.fromName(prefs.getS("profile", "BALANCED"))
        val st = ShizukuBridge.state(this@startBoost)
        vm.shizuku.value = st
        if (profile.scale < 1f && st == ShizukuState.CONNECTED) {
            val base = ResolutionManager.physical()
            if (base != null) {
                val t = ResolutionManager.target(base, profile.scale)
                val ok = ask(
                    "Apply ${profile.title}?",
                    "This may change display resolution for the whole phone.\n\nShizuku will run:\nwm size ${t.w}x${t.h}\n\nRESET RESOLUTION restores it anytime.",
                    "APPLY"
                )
                if (!ok) return@launch
            }
        }
        showBoostOverlay(profile, game, launchAfter)
    }
}

private suspend fun GameSpaceActivity.showBoostOverlay(profile: OptimizationProfile, game: GameInfo, launchAfter: Boolean) {
    val overlay = FrameLayout(this).apply { setBackgroundColor(0xE6000000.toInt()); isClickable = true }
    val title = label(getString(R.string.optimizing), 18f, Pal.text, true)
    val prog = ProgressBar(this).apply { isIndeterminate = true; indeterminateTintList = ColorStateList.valueOf(Pal.RED) }
    val steps = label("", 13f, Pal.text)
    val buttons = LinearLayout(this).apply { visibility = View.GONE }
    val panel = box().apply {
        put(label("SANJU SYSTEM X", 12f, Pal.RED, true).apply { letterSpacing = 0.2f }, 0)
        put(title, 4); put(prog, 4); put(steps, 6); put(buttons, 10)
    }
    overlay.addView(panel, FrameLayout.LayoutParams(dp(480), WRAP, Gravity.CENTER))
    rootFrame.addView(overlay, MATCH, MATCH)

    val sb = StringBuilder()
    val res = engine.run(profile, game) { s ->
        sb.append(s.mark).append(' ').append(s.text).append('\n')
        steps.text = sb.toString().trimEnd()
    }
    prog.visibility = View.GONE
    val good = res.failed.isEmpty()
    title.text = if (good) getString(R.string.game_ready) else "COMPLETED WITH ISSUES"
    title.setTextColor(if (good) Pal.GREEN else AMBER)
    sfx.play(R.raw.sfx_ready, 0.7f)
    val canLaunch = res.failed.none { it.text.startsWith("Game cannot") }

    buttons.addView(btn("LAUNCH GAME") { launchGame(game); rootFrame.removeView(overlay) }.also { it.isEnabled = canLaunch }, lp(0, WRAP, 1f))
    buttons.addView(btn("CLOSE", false) { rootFrame.removeView(overlay); renderSection() }, lp(0, WRAP, 1f).apply { marginStart = dp(8) })
    buttons.visibility = View.VISIBLE
    updateStatusBars()

    if (launchAfter && canLaunch && prefs.getB("autoLaunch", true)) {
        delay(1800)
        if (overlay.isAttachedToWindow) { launchGame(game); rootFrame.removeView(overlay) }
    }
}
